# Deprecated Blender exporters

Here you can find old versions of exporters, when too many breaking changes were done.

- *io_export_babylon.py* development has stopped since Blender 2.75
- *Blender2Babylon-5.6.zip* for Blender prior to Blender 2.80